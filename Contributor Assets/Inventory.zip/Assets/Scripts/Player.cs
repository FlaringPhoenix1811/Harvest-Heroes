using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    // public int numWatermelon = 0;
    // public int numTomato = 0;

    public Inventory inventory;

    private void Awake()
    {
        inventory = new Inventory(27);
    } 

    public void DropItem(Collectables item)
    {
        Vector3 spawnLocation = transform.position;
        // Vector2 spawnOffset = Random.insideUnitCircle * 1.25f;

        float randX = Random.Range(-1f, 1f);
        float randY = Random.Range(-1f, 1f);        
        Vector3 spawnOffset = new Vector3(randX,randY, 0f).normalized;

        Collectables droppedItem = Instantiate(item, spawnLocation + spawnOffset, Quaternion.identity);

        droppedItem.rb2d.AddForce(spawnOffset * .2f, ForceMode2D.Impulse);
    }
}
