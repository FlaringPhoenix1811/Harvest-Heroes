using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemManager : MonoBehaviour
{
    public Collectables[] collectableItems;

    private Dictionary<CollectableType, Collectables> collectableItemsDict = new Dictionary<CollectableType, Collectables>();

    private void Awake()
    {
        foreach(Collectables item in collectableItems)
        {
            AddItem(item);
        }
    }

    private void AddItem(Collectables item)
    {
        if(!collectableItemsDict.ContainsKey(item.type))
        {
            collectableItemsDict.Add(item.type, item);
        }
    }

    public Collectables GetItemByType(CollectableType type)
    {
        if(collectableItemsDict.ContainsKey(type))
        {
            return collectableItemsDict[type];
        }
        return null;
    }
}
